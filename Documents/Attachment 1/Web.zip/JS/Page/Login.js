﻿$(document).ready(
    function () {
        $("#Right").on("click", function () { Submit(); });

        $('#Logo').click(function () {
            $.ajax({ 
                url: 'http://localhost:8080/api/uauth/1',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
                }
            }).always(function (data) {
                alert(data);
            });
        });
    }

    
)

function Submit() {
    var U = $("#Username").val();
    var P = $("#Password").val();
    var data = "grant_type=password&Username=" + U + "&Password=" + P;
    $.post('http://localhost:8080/' + 'token', data)
        .then(function (data) {
            token = data.access_token;
            alert(token);
        });
}

var token;