﻿$(document).ready(
    function () {
        var Tooltip_Index = 1;

        $("[data-function='Tooltip']").each(
            function (index) {
                $(this).css("z-index", -1);
                $(this).css("position", "fixed");
                $(this).attr("id", "Tooltip_" + Tooltip_Index++).hide();
                $("#" + $(this).attr("data-tooltip-target")).attr("data-tooltip", $(this).attr("id"));
                $("#" + $(this).attr("data-tooltip-target")).on("mouseover", function () { Tooltip_FadeIn(this); });
                $("#" + $(this).attr("data-tooltip-target")).on("mouseleave", function () { Tooltip_FadeOut(this); });
            }
        )
    }
)

function Tooltip_FadeIn(_Object) {
    var T = $("#" + $(_Object).attr("data-tooltip"));
    var P = T.attr("data-tooltip-position");
    switch (P) {
        case "bottom-left": {
            T.css("left", $(_Object).offset().left);
            T.css("top", $(_Object).offset().top - $(window).scrollTop() + $(_Object).outerHeight());
            break;
        }
        case "right-top": {
            T.css("left", $(_Object).offset().left + $(_Object).outerWidth());
            T.css("top", $(_Object).offset().top);
        }
    }
    T.css("z-index", 10).fadeIn(150);
}

function Tooltip_FadeOut(_Object) {
    $("#" + $(_Object).attr("data-tooltip")).css("z-index", -1).fadeOut(150);
}