﻿$(document).ready(
    function () {
        sessionStorage.setItem("Api_Path", "http://localhost:8080");
        //sessionStorage.setItem("Api_Path", "http://damocles-api.azurewebsites.net");

        $("#left").on("click", function () { window.history.back(); });
    }
)