﻿$(document).ready(
    function () {

    }
)

function Change_Date() {
    //Validate date and status
}