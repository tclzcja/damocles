﻿var Node_ID = 1;
var Node = [];
var Node_Matrix = [];
var Flag_Outcome = 1;
var Outcome = [];
var Outcome_ID = 1;

$(document).ready(
    function () {

        //Disable right-click menu
        $("html").on("contextmenu", function (e) { e.preventDefault(); });


        //Enable mousewheel
        $("body").mousewheel(function (event, delta) {
            this.scrollLeft -= (delta * 50);
            event.preventDefault();
        })

        //Enable right-click menu
        //Enable mode switch
        $("#panel-schedule").on("mouseup", function (e) {
            if (e.button == 2) {
                //Popup(e.pageX - $("body").scrollLeft(), e.pageY, 1);
            }
            else {

            }
        });

        //Trigger schedule length change
        $("#length").on("change", function () { Update_Panel_Schedule_Background(); })

        //Trigger node create
        $("#node-create").on("click", function () { Create_Node(); });

        //Toggle the Outcome panel
        $("#node-outcome").on("click", function () {
            Update_Panel_Node_Outcome(Flag_Outcome);
            Flag_Outcome = Flag_Outcome == 1 ? 2 : 1;
        });

        $("#outcome-add").on("click", function () {
            Create_Outcome();
        });

        $("#outcome-confirm").on("click", function () {
            Update_Panel_Node_Outcome(Flag_Outcome);
            Flag_Outcome = Flag_Outcome == 1 ? 2 : 1;
        })
    }
)

function Create_Outcome() {
    var A = {
        id: Outcome_ID,
        name: $("#outcome-name").val(),
        description: $("#outcome-description").val(),
        extension: $("#outcome-extension").val()
    }

    var D = document.createElement("div");
    $(D).html((A.name.replace(" ", "") + "." + A.extension.replace(" ", "").replace(".", "")).toLowerCase());
    $(D).attr("data-id", Outcome_ID);
    Outcome_ID++;

    $(D).on("click", function () { Delete_Outcome(this); });

    $("#outcome").append(D);

    Outcome.push(A);
}

function Delete_Outcome(_Outcome) {
    var ID = $(_Outcome).attr("data-id");

    var i = 0;
    while (Outcome[i].id != ID)
        i++;

    Outcome.splice(i, 1);

    $(_Outcome).remove();
}

function Update_Panel_Node_Select() {

    $("#node-parent").html("<option value=0>This task belongs to...</option>");
    $("#node-previous").html("<option value=0>This task relies on...</option>");

    for (var i = 0; i < Node.length; i++) {
        var O1 = document.createElement("option");
        var O2 = document.createElement("option");
        $(O1).text(Node[i].name);
        $(O1).val(Node[i].id);
        $(O2).text(Node[i].name);
        $(O2).val(Node[i].id);
        $("#node-parent").append(O1);
        $("#node-previous").append(O2);
    }
}

function Create_Node() {
    var MCN = ($("#node-end").val() - $("#node-start").val()) * 10;
    var S = $("#node-start").val();
    var E = $("#node-end").val();

    var N = {
        id: Node_ID,
        name: $("#node-name").val().length > MCN ? $("#node-name").val().substring(0, MCN) + "..." : $("#node-name").val(),
        description: $("#node-description").val(),
        start: S,
        end: E,
        Outcome: Outcome
    }

    Node.push(N);

    var Stack = 0;
    var flag = true;

    while (flag) {
        flag = false;
        for (var j = 0; j < Node_Matrix.length; j++) {
            if (E <= Node_Matrix[j].start) {

            }
            else if (S >= Node_Matrix[j].end) {

            }
            else if (Stack == Node_Matrix[j].stack) {
                Stack++;
                flag = true;
            }
        }
    }

    Node_Matrix.push({
        id: Node_ID,
        start: S,
        end: E,
        stack: Stack
    });

    Node_ID++;

    $("#menu").fadeOut(100);

    Update_Panel_Node_Select();

    Update_Panel_Schedule_Canvas();

    Outcome = [];
    $("#outcome").html("");
    $("#outcome-name").val("");
    $("#outcome-description").val("");
    $("#outcome-extension").val("");

    $("#node-name").val("");
    $("#node-description").val("");
    $("#node-start").val("");
    $("#node-end").val("");

    $("#node-previous").val(0);
    $("#node-parent").val(0);
}

function Delete_Node(_Node) {
    var ID = $(_Node).attr("data-id");

    var i = 0;
    while (Node[i].id != ID)
        i++;

    Node.splice(i, 1);
    Node_Matrix.splice(i, 1);

    Update_Panel_Schedule_Canvas();
}

function Update_Panel_Schedule_Canvas() {

    $("#panel-schedule-canvas").html("");

    for (var i = 0; i < Node.length; i++) {

        var D = document.createElement("div");
        $(D).html(Node[i].name);
        $(D).attr("data-id", Node[i].id);
        $(D).css("top", 50 * Node_Matrix[i].stack);
        $(D).css("left", Node[i].start * 100 - 100 + 20 + 50 + 5);
        $(D).css("width", (Node[i].end - Node[i].start) * 100 - 30);

        $(D).on("click", function () { Delete_Node(this); });

        $("#panel-schedule-canvas").append(D);
    }
}

function Update_Panel_Schedule_Background() {
    $("#panel-schedule").fadeOut(100, function () {
        var N = $("#length").val();

        $("#panel-schedule-background tbody tr").html("");
        $("#panel-schedule").width(N * 100);

        for (var i = 0; i < $("#length").val() ; i++) {
            var TD1 = document.createElement("td");
            var TD2 = document.createElement("td");
            $(TD1).html("Day " + (i + 1));
            $("#panel-schedule-background tr:first-child").append(TD1);
            $("#panel-schedule-background tr:last-child").append(TD2);
        }

        $("#title-create").css("left", N * 100 + 40 + 960);
        $("#panel-create").css("left", N * 100 + 40 + 960);

        $("#title-node").fadeIn(100);
        $("#panel-node").fadeIn(100);

        $("#title-schedule").fadeIn(100);
        $("#panel-schedule").fadeIn(100);

        $("#title-create").fadeIn(100);
        $("#panel-create").fadeIn(100);
    })
}

function Update_Panel_Node_Outcome(_Mode) {
    if (_Mode == 1) {
        $("#node-outcome").css("background-color", "#F90");
        $("#title-outcome").fadeIn(100);
        $("#panel-outcome").fadeIn(100);
        $("#panel-schedule, #title-schedule, #panel-create, #title-create").animate({
            left: "+=340"
        });
    }
    else {
        $("#node-outcome").css("background-color", "");
        $("#title-outcome").fadeOut(100);
        $("#panel-outcome").fadeOut(100);
        $("#panel-schedule, #title-schedule, #panel-create, #title-create").animate({
            left: "-=340"
        });
    }
}