﻿$(document).ready(
    function () {
        var Tooltip_Index = 1;

        $("[data-function='tooltip']").each(
            function (index) {
                $(this).attr("class", "tooltip tooltip-hide");
                $(this).attr("id", "tooltip-" + Tooltip_Index++);
                $("#" + $(this).attr("data-tooltip-target")).attr("data-tooltip", $(this).attr("id"));
                $("#" + $(this).attr("data-tooltip-target")).on("mouseover", function () { Tooltip_FadeIn(this); });
                $("#" + $(this).attr("data-tooltip-target")).on("mouseleave", function () { Tooltip_FadeOut(this); });
            }
        )
    }
)

function Tooltip_FadeIn(_Object) {
    var T = $("#" + $(_Object).attr("data-tooltip"));
    var P = T.attr("data-tooltip-position");
    switch (P) {
        case "bottom-left": {
            T.css("left", $(_Object).offset().left);
            T.css("top", $(_Object).offset().top - $(window).scrollTop() + $(_Object).outerHeight());
            break;
        }
        case "bottom-right": {
            T.css("right", $(window).width() - $(_Object).offset().left - $(_Object).outerWidth());
            T.css("top", $(_Object).offset().top - $(window).scrollTop() + $(_Object).outerHeight());
            break;
        }
        case "right-top": {
            T.css("left", $(_Object).offset().left + $(_Object).outerWidth());
            T.css("top", $(_Object).offset().top);
            break;
        }
        case "left-top": {
            T.css("right", $(window).width() - $(_Object).offset().left);
            T.css("top", $(_Object).offset().top);
            break;
        }
    }
    T.attr("class", "tooltip tooltip-show");
}

function Tooltip_FadeOut(_Object) {
    $("#" + $(_Object).attr("data-tooltip")).attr("class", "tooltip tooltip-hide");
}