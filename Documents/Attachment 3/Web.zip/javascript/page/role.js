﻿var Role = {
    id: "",
    name: "",
    description: "",
    auth: []
}

$(document).ready(
    function () {
        switch ($.QueryString("mode")) {
            case "create": {
                Prepare_Create();
                break;
            }
            case "read": {
                Prepare_Read();
                break;
            }
            case "update": {
                Prepare_Update();
                break;
            }
        }
    }
)

function Prepare_Read() {
    $("#panel select, #panel input").hide();
    $("#name, #description").attr("class", "read");
    $("#right").hide();

    $("#footer").attr("class", "processing");
    $("#footer").html("Loading Role...");

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + '/api/role/' + $.QueryString("id"),
        type: "GET",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
        }
    }).success(function (data) {
        $("#footer").attr("class", "").html("");

        Role.id = data.data.id;
        Role.name = data.data.name;
        Role.description = data.data.description;
        Role.auth = data.data.auth;

        $("#name").html(Role.name);
        $("#description").html(Role.description);

        $("td.auth").attr("class", "auth read");

        if (Role.auth != null) {
            for (var i = 0; i < Role.auth.length; i++) {
                $("#auth-" + Role.auth[i]).attr("class", "auth selected read");
            }
        }
    }).error(function (jqXHR, textStatus, errorThrown) {
        $("#footer").attr("class", "error").html("Error: Can not load Role");
    })
}

function Prepare_Create() {
    $("#panel td.auth").on("click", function () { $(this).toggleClass("selected"); });
    $("#right").on("click", function () { Create(); });
}

function Prepare_Update() {
    $("#right").fadeOut(0);

    $("#footer").attr("class", "processing");
    $("#footer").html("Loading Role...");

    $("#panel td.auth").on("click", function () { $(this).toggleClass("selected"); });
    $("#right").on("click", function () { Update(); });

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + '/api/role/' + $.QueryString("id"),
        type: "GET",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
        }
    }).success(function (data) {

        $("#right").fadeIn(100);

        $("#footer").attr("class", "").html("");

        Role.id = data.data.id;
        Role.name = data.data.name;
        Role.description = data.data.description;
        Role.auth = data.data.auth;

        $("#name input").val(Role.name);
        $("#description textarea").val(Role.description);

        if (Role.auth != null) {
            for (var i = 0; i < Role.auth.length; i++) {
                $("#auth-" + Role.auth[i]).attr("class", "auth selected");
            }
        }

        $("#right").on("click", function () { Update(); });
    }).error(function (jqXHR, textStatus, errorThrown) {
        $("#footer").attr("class", "error").html("Error: Can not load Role");
    })
}

function Create() {

    $("#footer").attr("class", "processing");
    $("#footer").html("Creating Role...");

    $("#panel").fadeTo(100, 0.5);
    $("#panel input, #panel textarea").prop("disabled", true);
    $("#right").fadeTo(100, 0.5);
    $("#right").off();

    Role.name = $("#name input").val();
    Role.description = $("#description textarea").val();

    if ($("#auth-user-create").hasClass("selected")) {
        Role.auth.push("user-create");
    }
    if ($("#auth-user-manage").hasClass("selected")) {
        Role.auth.push("user-manage");
    }
    if ($("#auth-role-create").hasClass("selected")) {
        Role.auth.push("role-create");
    }
    if ($("#auth-role-manage").hasClass("selected")) {
        Role.auth.push("role-manage");
    }
    if ($("#auth-project-create").hasClass("selected")) {
        Role.auth.push("project-create");
    }
    if ($("#auth-project-manage").hasClass("selected")) {
        Role.auth.push("project-manage");
    }
    if ($("#auth-task-create").hasClass("selected")) {
        Role.auth.push("task-create");
    }
    if ($("#auth-task-manage").hasClass("selected")) {
        Role.auth.push("task-manage");
    }
    if ($("#auth-visualization-network").hasClass("selected")) {
        Role.auth.push("visualization-network");
    }
    if ($("#auth-visualization-workload").hasClass("selected")) {
        Role.auth.push("visualization-workload");
    }
    if ($("#auth-config").hasClass("selected")) {
        Role.auth.push("config");
    }

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + "/api/role",
        type: "POST",
        data: Role,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('authorization', 'Bearer ' + sessionStorage.getItem("auth_Token"));
        }
    }).success(function (data) {
        $("#footer").attr("class", "success").html("Successed");
        window.setTimeout(function () { $("#footer").attr("class", "").html(""); }, 2000);

        $("#panel").fadeTo(100, 1);
        $("#panel input").prop("disabled", false);
        $("#right").fadeTo(100, 1);
        $("#right").on("click", function () { Create(); });
    });
}

function Update() {

    $("#footer").attr("class", "processing");
    $("#footer").html("Updating Role...");

    $("#panel").fadeTo(100, 0.5);
    $("#panel input, #panel textarea").prop("disabled", true);
    $("#right").fadeTo(100, 0.5);
    $("#right").off();

    Role.name = $("#name input").val();
    Role.description = $("#description textarea").val();
    Role.auth = [];

    if ($("#auth-user-create").hasClass("selected")) {
        Role.auth.push("user-create");
    }
    if ($("#auth-user-manage").hasClass("selected")) {
        Role.auth.push("user-manage");
    }
    if ($("#auth-role-create").hasClass("selected")) {
        Role.auth.push("role-create");
    }
    if ($("#auth-role-manage").hasClass("selected")) {
        Role.auth.push("role-manage");
    }
    if ($("#auth-project-create").hasClass("selected")) {
        Role.auth.push("project-create");
    }
    if ($("#auth-project-manage").hasClass("selected")) {
        Role.auth.push("project-manage");
    }
    if ($("#auth-task-create").hasClass("selected")) {
        Role.auth.push("task-create");
    }
    if ($("#auth-task-manage").hasClass("selected")) {
        Role.auth.push("task-manage");
    }
    if ($("#auth-visualization-network").hasClass("selected")) {
        Role.auth.push("visualization-network");
    }
    if ($("#auth-visualization-workload").hasClass("selected")) {
        Role.auth.push("visualization-workload");
    }
    if ($("#auth-config").hasClass("selected")) {
        Role.auth.push("config");
    }

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + "/api/role/" + $.QueryString("id"),
        type: "PUT",
        data: Role,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('authorization', 'Bearer ' + sessionStorage.getItem("auth_Token"));
        }
    }).success(function (data) {
        $("#footer").attr("class", "success").html("Successed");
        window.setTimeout(function () { $("#footer").attr("class", "").html(""); }, 2000);

        $("#panel").fadeTo(100, 1);
        $("#panel input").prop("disabled", false);
        $("#right").fadeTo(100, 1);
        $("#right").on("click", function () { Update(); });
    });
}