﻿$(document).ready(
    function () {
        
    }
)