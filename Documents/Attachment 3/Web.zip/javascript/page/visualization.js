﻿var is_dragging = false;
var down_position_x;

$(document).ready(
    function () {
        $("body").mousewheel(function (event, delta) {
            this.scrollLeft -= (delta * 30);

            event.preventDefault();
        })
    }
)