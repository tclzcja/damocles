﻿var Task = [
    {
        name: "The first team meeting",
        start: 1,
        end: 3
    },
    {
        name: "The second team meeting",
        start: 4,
        end: 6
    },
    {
        name: "The third team meeting",
        start: 7,
        end: 9
    },
    {
        name: "Contact outsource company",
        start: 1,
        end: 4
    },
    {
        name: "Negotiation",
        start: 3,
        end: 6
    }, {
        name: "Legal documents and final confirm",
        start: 6,
        end: 10
    }, {
        name: "Contact audio company",
        start: 5,
        end: 9
    }, {
        name: "Negotiation",
        start: 8,
        end: 12
    }, {
        name: "Production",
        start: 11,
        end: 20
    },
]

var Task_Matrix = [];

$(document).ready(
    function () {

        //Disable right-click menu
        $("html").on("contextmenu", function (e) { e.preventDefault(); });


        //Enable mousewheel
        $("body").mousewheel(function (event, delta) {
            this.scrollLeft -= (delta * 50);
            event.preventDefault();
        })

        $("#template").on("change", function () {
            if ($("#template option:selected").val() == "1") {
                Update_Panel_Schedule_Background();
                Update_Panel_Schedule_Canvas();
            }
        });
    }
)

function Update_Panel_Schedule_Canvas() {

    for (var i = 0; i < Task.length; i++) {

        var S = Task[i].start;
        var E = Task[i].end;

        var Stack = 0;
        var flag = true;

        while (flag) {
            flag = false;
            for (var j = 0; j < Task_Matrix.length; j++) {
                if (E <= Task_Matrix[j].start) {

                }
                else if (S >= Task_Matrix[j].end) {

                }
                else if (Stack == Task_Matrix[j].stack) {
                    Stack++;
                    flag = true;
                }
            }
        }

        Task_Matrix.push({
            start: S,
            end: E,
            stack: Stack
        });

    }

    for (var i = 0; i < Task.length; i++) {

        var N = Task[i].end - Task[i].start;

        var D = document.createElement("div");
        $(D).html(Task[i].name.length > N * 10 ? Task[i].name.substr(0, N * 10) + "..." : Task[i].name);
        $(D).attr("data-id", Task[i].id);
        $(D).css("top", 50 * Task_Matrix[i].stack);
        $(D).css("left", Task[i].start * 100 - 100 + 20 + 50 + 5);
        $(D).css("width", (Task[i].end - Task[i].start) * 100 - 30);

        $("#panel-schedule-canvas").append(D);
    }
}

function Update_Panel_Schedule_Background() {

    $("#panel-schedule").fadeOut(100, function () {
        var N = 20;

        $("#panel-schedule-background tbody tr").html("");
        $("#panel-schedule").width(N * 100);

        for (var i = 0; i < N ; i++) {
            var TD1 = document.createElement("td");
            var TD2 = document.createElement("td");
            $(TD1).html("Day " + (i + 1));
            $("#panel-schedule-background tr:first-child").append(TD1);
            $("#panel-schedule-background tr:last-child").append(TD2);
        }

        $("#title-create").css("left", N * 100 + 40 + 580);
        $("#panel-create").css("left", N * 100 + 40 + 580);

        $("#title-Task").fadeIn(100);
        $("#panel-Task").fadeIn(100);

        $("#title-schedule").fadeIn(100);
        $("#panel-schedule").fadeIn(100);

        $("#title-create").fadeIn(100);
        $("#panel-create").fadeIn(100);
    })

}