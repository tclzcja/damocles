﻿$(document).ready(
    function () {

        sessionStorage.setItem("Auth_Pass", "0");
        sessionStorage.setItem("Auth_Token", "0");

        $("#right").on("click", function () { Submit(); });
    }
)

function Submit() {

    var data = {
        grant_type: "password",
        Username: $("#username").val(),
        Password: $("#password").val()
    }

    $("#panel").fadeTo(150, 0.5);
    $("#panel input").prop("disabled", true);
    $("#right").fadeTo(150, 0.5);
    $("#right").off();

    $.post(sessionStorage.getItem("Api_Path") + '/token', data).then(function (data) {
        sessionStorage.setItem("Auth_Pass", "1");
        sessionStorage.setItem("Auth_Token", data.access_token);
        var a = document.createElement("a");
        a.href = "./";
        window.location.href = a.href + "index.html";
    }).fail(function () {
        $("#panel").fadeTo(150, 1);
        $("#panel input").prop("disabled", false);
        $("#right").fadeTo(150, 1);
        $("#right").on("click", function () { Submit(); });
        $("#footer").html("Connection Failed");
        $("#footer").fadeIn(150).delay(2000).fadeOut(150);
    });
}