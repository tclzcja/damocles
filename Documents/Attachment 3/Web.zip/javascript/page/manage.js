﻿var User = [];
var Role = [];

$(document).ready(
    function () {
        List_Role();
        List_User();

        $("#menu img").on("click", function () {
            Switch(this);
        });

        Switch($("#menu img[data-table='panel-" + $.QueryString("type") + "']")[0]);
    }
)

function Switch(_Img) {
    $("#menu img").attr("class", "");
    $("#panel table").attr("class", "hide");

    $(_Img).attr("class", "selected");
    $("#panel table[id='" + $(_Img).attr("data-table") + "']").attr("class", "");
}

function List_Role() {

    $("#footer").attr("class", "processing");
    $("#footer").html("Loading Role list...");

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + '/api/role',
        type: "GET",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
        }
    }).success(function (data) {

        var L = data.data.rows;

        for (var i = 0; i < L.length; i++) {
            var R = {
                id: L[i][0],
                name: L[i][1],
                description: L[i][2],
                auth: L[i][3]
            }

            Role.push(R);
        }

        for (var i = 0; i < Role.length; i++) {
            var TR = document.createElement("tr");

            var TD_Name = document.createElement("td");
            var TD_Description = document.createElement("td");
            var TD_Auth = document.createElement("td");
            var TD_Read = document.createElement("td");
            var TD_Update = document.createElement("td");
            var TD_Delete = document.createElement("td");

            $(TD_Name).html(Role[i].name);
            $(TD_Name).attr("class", "fix");
            $(TD_Description).html(Role[i].description);
            if ($(TD_Description).html().length > 30) {
                $(TD_Description).html($(TD_Description).html().substr(0, 30) + "...");
            }
            $(TD_Description).attr("class", "fix");

            if (Role[i].auth != null) {
                for (var j = 0; j < Role[i].auth.length; j++) {
                    var S = document.createElement("span");
                    $(S).html(Role[i].auth[j]);
                    $(TD_Auth).append($(S));
                }
            }

            $(TD_Read).html("<img src='image/read.png' />");
            $(TD_Read).attr("data-id", Role[i].id);
            $(TD_Read).attr("data-type", "role");
            $(TD_Read).attr("class", "action");
            $(TD_Read).on("click", function () { Read(this); });
            $(TD_Update).html("<img src='image/update.png' />");
            $(TD_Update).attr("data-id", Role[i].id);
            $(TD_Update).attr("data-type", "role");
            $(TD_Update).attr("class", "action");
            $(TD_Update).on("click", function () { Update(this); });
            $(TD_Delete).html("<img src='image/delete.png' />");
            $(TD_Delete).attr("data-id", Role[i].id);
            $(TD_Delete).attr("data-type", "role");
            $(TD_Delete).attr("class", "action");
            $(TD_Delete).on("click", function () { Delete(this); });

            $(TR).append(TD_Name);
            $(TR).append(TD_Description);
            $(TR).append(TD_Auth);
            $(TR).append(TD_Read);
            $(TR).append(TD_Update);
            $(TR).append(TD_Delete);

            $("#panel-role tbody").append(TR);
        }
    })




}

function List_User() {

    $("#footer").attr("class", "processing");
    $("#footer").html("Loading User list...");

    User = [];

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + '/api/user',
        type: "GET",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
        }
    }).success(function (data) {

        var L = data.data.rows;

        for (var i = 0; i < L.length; i++) {
            var U = {
                id: L[i][0],
                name: L[i][2],
                email: L[i][1],
                role: []
            }

            for (var j = 0; j < L[i][3].length; j++) {
                var R = {
                    id: L[i][3][j].id,
                    name: L[i][3][j].name
                }
                U.role.push(R);
            }

            User.push(U);
        }

        for (var i = 0; i < User.length; i++) {
            var TR = document.createElement("tr");

            var TD_Name = document.createElement("td");
            var TD_Email = document.createElement("td");
            var TD_Role = document.createElement("td");
            var TD_Read = document.createElement("td");
            var TD_Update = document.createElement("td");
            var TD_Delete = document.createElement("td");

            $(TD_Name).html(User[i].name);
            $(TD_Name).attr("class", "fix");
            $(TD_Email).html(User[i].email);
            $(TD_Email).attr("class", "fix");
            for (var j = 0; j < User[i].role.length; j++) {
                var S = document.createElement("span");
                $(S).html(User[i].role[j].name);
                $(TD_Role).append($(S));
            }

            $(TD_Read).html("<img src='image/read.png' />");
            $(TD_Read).attr("data-id", User[i].id);
            $(TD_Read).attr("data-type", "user");
            $(TD_Read).attr("class", "action");
            $(TD_Read).on("click", function () { Read(this); });
            $(TD_Update).html("<img src='image/update.png' />");
            $(TD_Update).attr("data-id", User[i].id);
            $(TD_Update).attr("data-type", "user");
            $(TD_Update).attr("class", "action");
            $(TD_Update).on("click", function () { Update(this); });
            $(TD_Delete).html("<img src='image/delete.png' />");
            $(TD_Delete).attr("data-id", User[i].id);
            $(TD_Delete).attr("data-type", "user");
            $(TD_Delete).attr("class", "action");
            $(TD_Delete).on("click", function () { Delete(this); });

            $(TR).append(TD_Name);
            $(TR).append(TD_Email);
            $(TR).append(TD_Role);
            $(TR).append(TD_Read);
            $(TR).append(TD_Update);
            $(TR).append(TD_Delete);

            $("#panel-user tbody").append(TR);
        }

        $("#footer").attr("class", "");
        $("#footer").html("");
    });


}

function Read(_Obj) {
    switch ($(_Obj).attr("data-type")) {
        case "user": {
            var a = document.createElement("a");
            a.href = "./";
            window.location.href = a.href + "user.html?mode=read&id=" + $(_Obj).attr("data-id");
            break;
        }
        case "role": {
            var a = document.createElement("a");
            a.href = "./";
            window.location.href = a.href + "role.html?mode=read&id=" + $(_Obj).attr("data-id");
            break;
        }
    }
}

function Update(_Obj) {
    switch ($(_Obj).attr("data-type")) {
        case "user": {
            var a = document.createElement("a");
            a.href = "./";
            window.location.href = a.href + "user.html?mode=update&id=" + $(_Obj).attr("data-id");
            break;
        }
        case "role": {
            var a = document.createElement("a");
            a.href = "./";
            window.location.href = a.href + "role.html?mode=update&id=" + $(_Obj).attr("data-id");
            break;
        }
    }
}

function Delete(_Obj) {

    $("#footer").attr("class", "processing");
    $("#footer").html("Deleting Object...");

    switch ($(_Obj).attr("data-type")) {
        case "user": {
            $.ajax({
                url: sessionStorage.getItem("Api_Path") + '/api/user/' + $(_Obj).attr("data-id"),
                type: "DELETE",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
                }
            }).success(function (data) {
                $("#footer").attr("class", "success");
                $("#footer").html("Object deleted");
                window.location.reload();
            }).error(function (jqXHR, textStatus, errorThrown) {
                $("#footer").attr("class", "error").html("Error: Can not delete object");
                window.setTimeout(function () { $("#footer").attr("class", "").html(); }, 2000);
            })
        }
        case "role": {
            $.ajax({
                url: sessionStorage.getItem("Api_Path") + '/api/role/' + $(_Obj).attr("data-id"),
                type: "DELETE",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
                }
            }).success(function (data) {
                $("#footer").attr("class", "success");
                $("#footer").html("Object deleted");
                window.location.reload();
            }).error(function (jqXHR, textStatus, errorThrown) {
                $("#footer").attr("class", "error").html("Error: Can not delete object");
                window.setTimeout(function () { $("#footer").attr("class", "").html(); }, 2000);
            })
        }
    }


}