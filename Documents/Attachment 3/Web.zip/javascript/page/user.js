﻿var Role_List = []

var User = {
    id: "",
    name: "",
    email: "",
    role: []
}

$(document).ready(
    function () {
        switch ($.QueryString("mode")) {
            case "create": {
                Prepare_Create();
                break;
            }
            case "read": {
                Prepare_Read();
                break;
            }
            case "update": {
                Prepare_Update();
                break;
            }
        }
    }
)

function Prepare_Create() {

    $("#right").hide();

    $("#footer").attr("class", "processing");
    $("#footer").html("Loading Role list...");

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + '/api/role',
        type: "GET",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
        }
    }).success(function (data) {

        Role_List = data.data.rows;
        for (var i = 0; i < Role_List.length; i++) {
            var O = document.createElement("option");
            $(O).attr("value", Role_List[i][0]);
            $(O).html(Role_List[i][1]);
            $("#role select").append($(O));
        }

        $("#footer").attr("class", "").html("");

        $("#right").fadeIn(100).on("click", function () { Create(); });

        $("#role select").on("change", function () {
            var V = $("#role select").val();
            if (V != "0") {
                if ($("#role div[data-id=" + V + "]").length == 0) {
                    var D = document.createElement("div");
                    $(D).attr("data-id", $("#role select").val());
                    $(D).html($("#role select option:selected").text());
                    $(D).on("click", function () { $(this).remove(); });
                    $("#role").append($(D));
                }
            }
        });

    }).error(function (jqXHR, textStatus, errorThrown) {
        $("#footer").attr("class", "error").html("Error: Can not load Role list");
        $("#right").fadeOut(100);
    })
}

function Prepare_Read() {
    $("#panel select, #panel input").hide();
    $("#name, #email").attr("class", "read");
    $("#right").hide();

    $("#footer").attr("class", "processing");
    $("#footer").html("Loading User...");

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + '/api/user/' + $.QueryString("id"),
        type: "GET",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
        }
    }).success(function (data) {
        $("#footer").attr("class", "").html("");

        User.id = data.data.id;
        User.name = data.data.name;
        User.email = data.data.email;
        User.role = data.data.role;

        $("#name").html(User.name);
        $("#email").html(User.email);

        if (User.role != null) {
            for (var i = 0; i < User.role.length; i++) {
                var D = document.createElement("div");
                $(D).html(User.role[i].name);
                $(D).attr("class", "read");
                $("#role").append($(D));
            }
        }
    }).error(function (jqXHR, textStatus, errorThrown) {
        $("#footer").attr("class", "error").html("Error: Can not load User");
    })
}

function Prepare_Update() {
    $("#right").hide();

    $("#footer").attr("class", "processing");
    $("#footer").html("Loading Role list...");

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + '/api/role',
        type: "GET",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
        }
    }).success(function (data) {
        //After loading Role list
        Role_List = data.data.rows;

        for (var i = 0; i < Role_List.length; i++) {
            var O = document.createElement("option");
            $(O).attr("value", Role_List[i][0]);
            $(O).html(Role_List[i][1]);
            $("#role select").append($(O));
        }

        $("#footer").attr("class", "").html("");

        $("#right").fadeIn(100).on("click", function () { Update(); });

        $("#role select").on("change", function () {
            var V = $("#role select").val();
            if (V != "0") {
                if ($("#role div[data-id=" + V + "]").length == 0) {
                    var D = document.createElement("div");
                    $(D).attr("data-id", $("#role select").val());
                    $(D).html($("#role select option:selected").text());
                    $(D).on("click", function () { $(this).remove(); });
                    $("#role").append($(D));
                }
            }
        });

        $("#footer").attr("class", "processing");
        $("#footer").html("Loading User...");

        $.ajax({
            url: sessionStorage.getItem("Api_Path") + '/api/user/' + $.QueryString("id"),
            type: "GET",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
            }
        }).success(function (data) {
            //After loading User
            $("#footer").attr("class", "").html("");

            User.id = data.data.id;
            User.name = data.data.name;
            User.email = data.data.email;
            User.role = data.data.role;

            $("#name input").val(User.name);
            $("#email input").hide();
            $("#email").html(User.email).attr("class", "read");

            if (User.role != null) {
                for (var i = 0; i < User.role.length; i++) {
                    var D = document.createElement("div");
                    $(D).html(User.role[i].name);
                    $(D).attr("data-id", User.role[i].id);
                    $(D).on("click", function () { $(this).remove(); });
                    $("#role").append($(D));
                }
            }

            $("#role select").on("change", function () {
                var V = $("#role select").val();
                if (V != "0") {
                    if ($("#role div[data-id=" + V + "]").length == 0) {
                        var D = document.createElement("div");
                        $(D).attr("data-id", $("#role select").val());
                        $(D).html($("#role select option:selected").text());
                        $(D).on("click", function () { $(this).remove(); });
                        $("#role").append($(D));
                    }
                }
            });

            $("#right").fadeIn(100).on("click", function () { Update(); });

        }).error(function (jqXHR, textStatus, errorThrown) {
            $("#footer").attr("class", "error").html("Error: Can not load User");
            $("#right").fadeOut(100);
        })

    }).error(function (jqXHR, textStatus, errorThrown) {
        $("#footer").attr("class", "error").html("Error: Can not load Role list");
        $("#right").fadeOut(100);
    })
}

function Create() {
    User.name = $("#name input").val();
    User.email = $("#email input").val();
    $("#role div").each(function () {
        R = {
            id: $(this).attr("data-id"),
            name: $(this).html()
        }
        User.role.push(R);
    })

    $("#panel").fadeTo(100, 0.5);
    $("#panel input, #panel select").attr("disabled", true);
    $("#right").fadeTo(100, 0.5);
    $("#right").off();

    $("#footer").attr("class", "processing");
    $("#footer").html("Processing");

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + '/api/user',
        type: "POST",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
        },
        data: User
    }).always(function (data) {
        $("#panel").fadeTo(100, 1);
        $("#panel input, #panel select").attr("disabled", false);
        $("#right").fadeTo(100, 1);
        $("#right").on("click", function () { Create(); });
    }).success(function (data) {
        $("#footer").attr("class", "success").html("Successed");
        window.setTimeout(function () { $("#footer").attr("class", "").html(""); }, 2000);
    }).error(function (jqXHR, textStatus, errorThrown) {
        $("#footer").attr("class", "error").html("Error");
        window.setTimeout(function () { $("#footer").attr("class", "").html(""); }, 2000);
    })
}

function Update() {
    User.id = $.QueryString("id");
    User.name = $("#name input").val();
    //User.email = $("#email input").val();
    User.role = [];
    $("#role div").each(function () {
        R = {
            id: $(this).attr("data-id"),
            name: $(this).html()
        }
        User.role.push(R);
    })

    $("#panel").fadeTo(100, 0.5);
    $("#panel input, #panel select").attr("disabled", true);
    $("#right").fadeTo(100, 0.5);
    $("#right").off();

    $("#footer").attr("class", "processing");
    $("#footer").html("Processing");

    $.ajax({
        url: sessionStorage.getItem("Api_Path") + '/api/user/' + $.QueryString("id"),
        type: "PUT",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Auth_Token"));
        },
        data: User
    }).always(function (data) {
        $("#panel").fadeTo(100, 1);
        $("#panel input, #panel select").attr("disabled", false);
        $("#right").fadeTo(100, 1);
        $("#right").on("click", function () { Create(); });
    }).success(function (data) {
        $("#footer").attr("class", "success").html("Successed");
        window.setTimeout(function () { $("#footer").attr("class", "").html(""); }, 2000);
    }).error(function (jqXHR, textStatus, errorThrown) {
        $("#footer").attr("class", "error").html("Error");
        window.setTimeout(function () { $("#footer").attr("class", "").html(""); }, 2000);
    })
}