﻿$(document).ready(
    function () {

        if (sessionStorage.getItem("Auth_Pass") != "1") {
            var a = document.createElement("a");
            a.href = "./";
            window.location.href = a.href + "login.html";
        }
        else {
            $("#header-user-logout").on("click", function () {
                sessionStorage.clear();
                var a = document.createElement("a");
                a.href = "./";
                window.location.href = a.href + "login.html";
            })
        }

    }
)